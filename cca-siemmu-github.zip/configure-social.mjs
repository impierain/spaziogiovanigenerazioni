import { readFile, writeFile } from 'node:fs/promises';

const site = new URL(process.argv[2]);
if (site.protocol !== 'https:' || site.username || site.password || site.search || site.hash) {
 throw new Error('Indica l’indirizzo HTTPS del sito, senza credenziali, parametri o frammenti.');
}
site.pathname = site.pathname.replace(/\/?$/, '/');
const image = new URL('copertina-social.png', site).href;
const index = new URL('./dist/index.html', import.meta.url);
const tags = await readFile(index, 'utf8');
await writeFile(index, tags.replace(
 /(<meta (?:property|name)="(og:url|og:image|twitter:image)" content=")[^"]*(")/g,
 (_, opening, key, closing) => opening + (key === 'og:url' ? site.href : image) + closing
));
